//
//  ViewController.swift
//  DatepickerDemo
//
//  Created by mspc-01 on 28/12/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtDate: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let date = UIDatePicker()
        date.datePickerMode = .date
        date.preferredDatePickerStyle = .wheels
        date.addTarget(self, action: #selector(dateChange(datepicker:)), for: UIControl.Event.valueChanged)
        
        date.frame.size = CGSize(width: 0, height: 300)
        txtDate.inputView = date
//        txtDate.text = formateDate(date: Date())
        
        
    }

    @objc func dateChange(datepicker: UIDatePicker){
        txtDate.text = formateDate(date: datepicker.date)
    }
    
    func formateDate(date: Date) -> String{
        let formatter = DateFormatter()
        formatter.dateFormat = "dd MM yyyy"
        formatter.dateStyle = .medium
        return formatter.string(from: date)
    }

}

